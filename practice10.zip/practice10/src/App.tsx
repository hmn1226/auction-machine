import React, { useState } from "react";
import { useWebSocket } from "./hooks/useWebSocket"; // カスタムフックをインポート

const App: React.FC = () => {
  // WebSocket フックを使う
  const { connect, disconnect, sendMessage, messages, isConnected } = useWebSocket();

  // 入力フォームの状態管理
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  // メッセージ送信処理
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      sendMessage({ name, message });
      setMessage("");
    }
  };

  return (
    <div id="main-content" className="container">
      <div className="row">
        <div className="col-md-6">
          <form className="form-inline" onSubmit={connect}>
            <div className="form-group">
              <label htmlFor="connect">WebSocket connection:</label>
              <button
                id="connect"
                className="btn btn-default"
                type="button"
                onClick={connect}
                disabled={isConnected}
              >
                Connect
              </button>
              <button
                id="disconnect"
                className="btn btn-default"
                type="button"
                onClick={disconnect}
                disabled={!isConnected}
              >
                Disconnect
              </button>
            </div>
          </form>
        </div>
        <div className="col-md-6">
          <form className="form-inline" onSubmit={handleSend}>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input
                type="text"
                id="name"
                className="form-control"
                placeholder="Your name here..."
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <input
                type="text"
                id="message"
                className="form-control"
                placeholder="Hello"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
            </div>
            <button id="send" className="btn btn-default" type="submit">
              Send
            </button>
          </form>
        </div>
      </div>
      <div className="row">
        <div className="col-md-12">
          <table id="conversation" className="table table-striped">
            <thead>
              <tr>
                <th>Messages</th>
              </tr>
            </thead>
            <tbody id="greetings">
              {messages.map((msg, index) => (
                <tr key={index}>
                  <td>{msg}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default App;